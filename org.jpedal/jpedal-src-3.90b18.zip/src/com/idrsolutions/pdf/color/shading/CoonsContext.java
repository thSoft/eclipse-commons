/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2008, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * FunctionContext.java
  * ---------------
 */
package com.idrsolutions.pdf.color.shading;

import java.awt.*;
import java.awt.image.ColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;

import java.util.ArrayList;

import org.jpedal.PdfDecoder;
import org.jpedal.objects.raw.PdfDictionary;
import org.jpedal.objects.raw.PdfObject;
import org.jpedal.color.GenericColorSpace;
import org.jpedal.function.PDFFunction;

public class CoonsContext implements PaintContext {

    GenericColorSpace shadingColorSpace;

    private double scaling=1f;

    private PDFFunction function;

    private CoonsContext(){}

    private int pageHeight;

    private boolean colorsReversed;

    private int xstart,ystart,w,h;

    private ArrayList patches;

    private float[] domain;
    private Shape shape;

    private WritableRaster raster;

    //flag to show if we have coded this in yet and gracefully ignore otherwise
    private boolean isImplemented=false;


    public CoonsContext(PdfObject shadingObj, int pHeight,double scaling,float[] domain,
                        GenericColorSpace shadingColorSpace,boolean colorsReversed, PDFFunction function,Shape shape){
        patches = new ArrayList();
        this.colorsReversed=colorsReversed;
        this.pageHeight=pHeight;
        this.domain=domain;

        this.shadingColorSpace=shadingColorSpace;
        this.function = function;
        this.scaling=scaling;

        //specific coons values
        int BitsPerComponent=shadingObj.getInt(PdfDictionary.BitsPerComponent);
        int BitsPerFlag=shadingObj.getInt(PdfDictionary.BitsPerFlag);
        int BitsPerCoordinate=shadingObj.getInt(PdfDictionary.BitsPerCoordinate);

        int compCount=shadingColorSpace.getColorComponentCount();

        this.shape = shape;

        //assume okay and reset if not
        isImplemented=true;

        //Decode the coordinate data
        byte[] bytes = shadingObj.getDecodedStream();
        CoonsDatastreamReader c = new CoonsDatastreamReader(bytes,BitsPerCoordinate,BitsPerComponent,compCount,BitsPerFlag,shadingColorSpace,function);
        patches = c.getPatches();

    }
    public void dispose() {}

    public ColorModel getColorModel() { return ColorModel.getRGBdefault(); }

    /**
     * setup the raster with the colors
     * */
    public Raster getRaster(int xstart, int ystart, int w, int h) {
        System.out.println("Raster:"+xstart+","+ystart+" - "+w+","+h);
        System.out.println("Shape: "+shape.getBounds().getMinX()*scaling+","+(pageHeight-(shape.getBounds().getMinY()*scaling))+" - "+
                shape.getBounds().getWidth()*scaling+","+shape.getBounds().getHeight()*scaling);

        this.xstart=xstart;
        this.ystart=ystart;
        this.w=w;
        this.h=h;

        //sets up the array of pixel values
        raster =getColorModel().createCompatibleWritableRaster(w, h);


        //if not yet added just return blank raster
        if(!isImplemented)
            return raster;


        //create buffer to hold all this data
   //     int[] data = new int[w * h * 4];

        //Create scaling and sample size values
        double wscale = 1.5*shape.getBounds().getWidth()*scaling;
        double hscale = 1.5*shape.getBounds().getHeight()*scaling;
        double wshift = 0;
        wshift = (xstart-(shape.getBounds().getMinX()*scaling))-(0.5*scaling);
        double hshift = 0;
        hshift = (ystart-(pageHeight-(shape.getBounds().getMaxY()*scaling)))-(0.5*scaling);
        System.out.println("Shift: "+wshift+","+hshift);
        double wsample = 0.1;
        double hsample = 0.1;
        boolean isAlreadyColored[][]=new boolean[raster.getWidth()][raster.getHeight()];
        int limit=patches.size();

        //Go through patches
        for(int c=0; c<limit; c++) {
            CoonsPatch p = (CoonsPatch) patches.get(c);
            wsample = 1/(p.getWidth()*shape.getBounds().getWidth()*scaling*10);
            hsample = 1/(p.getHeight()*shape.getBounds().getHeight()*scaling*10);
//            System.out.println("This Patch has "+(1/wsample)+" sample points per line.");
//            System.out.println(scaling);

            //Y coordinates
            for (int j=0; j<(1/hsample); j++) {
                //X coordinates
                for (int i=0; i<(1/wsample); i++) {

                    //Retrieve mapped coordinates within raster space
                    double[] coords = p.mapping(wsample*i,hsample*j);

                    //Scale coordinates
                    int px= (int) ((wscale*coords[0])-wshift);
                    int py= (int) ((hscale*coords[1])-hshift);
                    
                    //Check still inside raster space and not already colored
                    final boolean fillBorders=true;
                    if (((!fillBorders && px>0 && py>0)||(fillBorders && px>=0 && py>=0))
                            &&px<w && py<h && !isAlreadyColored[px][py]) {
                        //Calculate color and write
                        Color col = p.calculateColor(wsample*i,hsample*j);
                        int[] color = {col.getRed(),col.getGreen(),col.getBlue(),255};
                        isAlreadyColored[px][py]=true;
                        raster.setPixel(px,py,color);
                    }
                }
            }
        }
        return raster;
    }
}