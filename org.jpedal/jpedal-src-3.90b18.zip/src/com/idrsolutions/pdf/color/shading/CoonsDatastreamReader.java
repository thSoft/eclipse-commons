/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2008, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * CoonsDatastreamReader.java
  * ---------------
 */
package com.idrsolutions.pdf.color.shading;

import org.jpedal.color.GenericColorSpace;
import org.jpedal.function.PDFFunction;

import java.util.ArrayList;

public class CoonsDatastreamReader {

    byte[] data;

    private int pointer=0;

    private int bitsPerCoord,bitsPerComp,compCount,bitsPerFlag;

    private boolean processed=false;

    private GenericColorSpace shadingColorSpace;

    private ArrayList patches;

    private PDFFunction function;

    public CoonsDatastreamReader(byte[] data,int bitsPerCoord,int bitsPerComp,int compCount,int bitsPerFlag,GenericColorSpace shadingColorSpace,PDFFunction function){
        patches = new ArrayList();
        this.data=data;
        this.bitsPerCoord = bitsPerCoord;
        this.bitsPerComp = bitsPerComp;
        this.compCount = compCount;
        this.bitsPerFlag = bitsPerFlag;
        this.shadingColorSpace = shadingColorSpace;
        this.function = function;
    }

    /**
     * Returns the patches.
     * @return
     */
    public ArrayList getPatches() {
        if(!processed) {
            process();
            processed=true;
        }
        return patches;
    }

    /**
     * Processes the patch data and creates the patch objects.
     */
    private void process() {
        while (pointer < data.length) {
            if(bitsPerFlag==8) {
                if (data[pointer]==0) {
                    pointer++;
                    CoonsPatch patch = new CoonsPatch(compCount,shadingColorSpace,function);

                    //Retrieve 12 pairs of coordinates
                    for (int i=0;i<12;i++) {
                        patch.addPoint(getDecimal(bitsPerCoord),getDecimal(bitsPerCoord));
                    }

                    //Retrieve 4 sets of color values
                    for (int i=0;i<4;i++) {
                        for (int c=0;c<compCount;c++) {
                            patch.addColorValue(getDecimal(bitsPerComp));
                        }
                    }

                    patches.add(patch);
                }
                else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    /**
     * Returns a number between 0 and 1 represented by an arbitrary number of bits.
     * @param bits
     * @return
     */
    private float getDecimal(int bits) {
        if(bits==16) {
            float number,dec;

            number=(data[pointer]&255)/256f;

            pointer++;

            dec=(data[pointer]&255)/65536f;

            pointer++;

            return (number+dec);
        }
        else if(bits==8) {
            float number;
            number=(data[pointer]&255)/256f;
            pointer++;
            return number;
        }
        else {
            return 0;
        }
    }
}
