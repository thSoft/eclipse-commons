/**
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* (C) Copyright 1997-2008, IDRsolutions and Contributors.
*
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* CoonsPatch.java
* ---------------
*/
package com.idrsolutions.pdf.color.shading;

import org.jpedal.color.GenericColorSpace;

import java.awt.*;
import java.util.ArrayList;

import org.jpedal.function.PDFFunction;

public class CoonsPatch {

    // Points stored in order of: 1, 1 control towards 2, 2 control towards 1, 2...
    // Each coordinate refers to a proportional position between 0 and 1 on the raster. (Probably.)
    private double[] points = new double[24];

    private int pointsAdded;

    private int colorCompCount;

    private int colorCompsAdded=0;

    private float[][] colors;
    private ArrayList actualColors;

    private boolean colorsInitialised=false;

    private PDFFunction function;

    private double minX,minY,maxX,maxY,maxCP=0;

    private GenericColorSpace shadingColorSpace;

    public CoonsPatch(int colorCompCount, GenericColorSpace shadingColorSpace, PDFFunction function) {
        this.colorCompCount = colorCompCount;
        colors = new float[4][colorCompCount];
        this.shadingColorSpace = shadingColorSpace;
        this.function=function;
        minX = Integer.MAX_VALUE;
        minY = Integer.MAX_VALUE;
    }

    /**
     * Stores a points x and y coordinates. Points must be added in order, as defined above.
     * @param x x coordinate
     * @param y y coordinate
     */
    public void addPoint(double x, double y) {
        points[pointsAdded*2] = x;
        if (x>maxX) maxX = x;
        if (x<minX) minX = x;
        points[(pointsAdded*2)+1] = y;
        if (y>maxY) maxY = y;
        if (y<minY) minY = y;
        pointsAdded++;
    }

    public double getWidth() {
        return maxX-minX;
    }

    public double getHeight() {
        return maxY-minY;
    }

    public double getMaxCPLength() {
        if(maxCP != 0)
            return maxCP;
        for (int i=0; i<4; i++) {
            double a = getDistance(-1,0);
            double b = getDistance(0,1);
            if (a>maxCP)
                maxCP=a;
            if (b>maxCP)
                maxCP=b;
        }
        return maxCP;
    }

    public double getFlexFactor() {
        return getMaxCPLength()/((getWidth()+getHeight())/4);
    }

    private double getDistance(int point1, int point2) {
        double x1 = points[((point1+24)*2)%24];
        double x2 = points[((point2+24)*2)%24];
        double y1 = points[(((point1+24)*2)+1)%24];
        double y2 = points[(((point2+24)*2)+1)%24];

        return Math.sqrt(Math.pow((x2-x1),2)+Math.pow((y2-y1),2));
    }

    /**
     * Stores a color value. Must be added in order.
     * @param c single color value
     */
    public void addColorValue(float c) {
        colors[colorCompsAdded/colorCompCount][colorCompsAdded%colorCompCount] = c;
        colorCompsAdded++;
    }

    /**
     * Sets up the colors.
     */
    private void initialiseColors() {
        actualColors = new ArrayList();
        for(int i=0; i<4; i++) {
            //Retrieve values from array
            float[] values = new float[colors.length];
            for(int j=0; j<colors.length;j++) {
                values[j] = colors[i][j];
            }

            //Convert to a color
            shadingColorSpace.setColor(values,values.length);
            Color c = (Color) shadingColorSpace.getColor();

            actualColors.add(c);
        }
    }

    /**
     * Checks whether the specified coordinate is within the boundaries created by the
     * most extreme control points.
     * @param x
     * @param y
     * @return
     */
    public boolean contains(double x, double y) {
        if ((x > minX && x < maxX)&&(y > minY && y < maxY)) return true;
        return false;
    }

    /**
     * returns the coordinates of a specified point on the curve starting at point fp (0-3 clockwise from start).
     * @param t
     * @param fp
     * @return
     */
    private double[] bezier(double t, int fp) {
        int b = 6*fp;
        double[] result = new double[2];
        double pow1t3 = Math.pow((1-t),3);
        double pow1t2 = 3*t*Math.pow((1-t),2);
        double powt2 = 3*Math.pow(t,2)*(1-t);
        double powt3 = Math.pow(t,3);
        result[0] = (pow1t3*points[b]) + (pow1t2*points[b+2]) +
                        (powt2*points[b+4]) + (powt3*points[(b+6)%24]);
        result[1] = (pow1t3*points[b+1]) + (pow1t2*points[b+3]) +
                        (powt2*points[b+5]) + (powt3*points[(b+7)%24]);
        return result;
    }

    public double[] mapping(double x, double y) {
     //   System.out.println("Coords: "+points[0]+","+points[1]+"   "+points[6]+","+points[7]+"   "+points[12]+","+points[13]+"   "+points[18]+","+points[19]);
        double[] result = new double[2];
        double[] bezX3=bezier(x,3);
        double[] bezX1=bezier(x,1);
        result[0] = ((1-y)* bezX3[0])+(y*bezX1[0]);
        result[1] = ((1-y)* bezX3[1])+(y*bezX1[1]);
        double[] bezY0=bezier(y,0);
        double[] bezY2=bezier(y,2);
        result[0] += ((1-x)*bezY0[0]) + (x * bezY2[0]);
        result[1] += ((1-x)*bezY0[1]) + (x * bezY2[1]);
        double[] bez03=bezier(0,3);
        double[] bez13=bezier(1,3);
        double[] bez10=bezier(1,0);
        double[] bez11=bezier(1,1);
        result[0] = result[0] - (((1-y)*(((1-x)*bez03[0])+(x*bez13[0])))
                                    + (y * (((1-x)*bez10[0])+(x*bez11[0]))));
        result[1] = result[1] - (((1-y)*(((1-x)*bez03[1])+(x*bez13[1])))
                                    + (y * (((1-x)*bez10[1])+(x*bez11[1]))));
        return result;
    }                     

    /**
     * Calculates the color at a specified point.
     * @param x
     * @param y
     * @return
     */
    public Color calculateColor(double x, double y) {
        /**
		   A      B  < yt
              P
           C      D  < yb
           ^      ^
           xl     xr

		double xl,yt,xr,yb;
        if(PdfDecoder.isRunningOnMac){
			xl=scaling*xstart;
            yt=scaling*(ystart+h);
            xr=scaling*(xstart+w);
            yb=scaling*ystart;
		}else{
			xl=scaling*xstart;
            yt=scaling*(pageHeight-(ystart+h));
            xr=scaling*(xstart+w);
            yb=scaling*(pageHeight-ystart);
		}

		if(1==0)
            return new Color(255,255,0);


    //    double[] coords = mapping(x,y);
    //    x = (double) coords[0];
    //    y = (double) coords[1];
        */

        if(!colorsInitialised)
            initialiseColors();



        //Calculate proportions of each color
        double a = (1-x)*y;
        double b = x*y;
        double c = (1-x)*(1-y);
        double d = x*(1-y);

        Color c1 = (Color) actualColors.get(0);
        Color c2 = (Color) actualColors.get(1);
        Color c3 = (Color) actualColors.get(2);
        Color c4 = (Color) actualColors.get(3);     /**/

    /*    Color c1 = Color.red;
        Color c2 = Color.green;
        Color c3 = Color.blue;
        Color c4 = Color.white;                    /**/

        double red = ((c1.getRed()*a)+(c2.getRed()*b)+(c3.getRed()*c)+(c4.getRed()*d));
        double green = ((c1.getGreen()*a)+(c2.getGreen()*b)+(c3.getGreen()*c)+(c4.getGreen()*d));
        double blue = ((c1.getBlue()*a)+(c2.getBlue()*b)+(c3.getBlue()*c)+(c4.getBlue()*d));
        Color result = new Color((int)red, (int)green, (int)blue);
        
        return result;
       // return Color.blue;
    }

    public double[] getPoints() {
        return points;
    }
}
