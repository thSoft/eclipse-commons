package org.jfr.examples;

public class FontMatrix {

	public static void main(String[] args){
		FontDisplay fd = new FontDisplay();
		fd.setupViewer();
	}
}
