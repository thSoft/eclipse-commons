This the source code for the LGPL version of JPedal - a cutdown viewer from the full JPedal library

The src directory contains the source code building JPedal (LGPL version). It is supplied without
any warranty or support.

If you wish to use JPedal (or any part) in a LGPL product, you merely need to ensure you
fully comply with the LGPL license.

The enhanced commercial version is supported and fully tested by IDRsolutions

IDRsolutions
May 2009
